# XGO-PythonLib

XGO2 robot can be developed using the Python language.The motion,pose,coordinates,gripper and servo of the XGO2 can be controlled via Python. The detailed instructions for use of the library are as follows.

PythonLib included xgolib.py xgoedu.py xgoadvance.py.

[Luwu Dynamics · WIKI](https://www.yuque.com/luwudynamics)

[PythonLib-WIKI](https://www.yuque.com/luwudynamics/cn/mxkaodwpo2h5zmvw)



## Install instructions 

```
pip install xgo-pythonlib
```

All model files in model folder needs to be copyed to /hone/pi/model

img version 0512

